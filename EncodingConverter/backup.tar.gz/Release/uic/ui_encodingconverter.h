/********************************************************************************
** Form generated from reading UI file 'encodingconverter.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ENCODINGCONVERTER_H
#define UI_ENCODINGCONVERTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_EncodingConverterClass
{
public:
    QAction *actOpenDir;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout;
    QPushButton *btnSrcDir;
    QLineEdit *srcDirText;
    QLabel *label;
    QComboBox *cboSrcEn;
    QPushButton *btnDstDir;
    QLineEdit *dstDirText;
    QLabel *label_2;
    QComboBox *cboDstEn;
    QPushButton *btnStart;
    QSplitter *splitter_2;
    QTreeView *treeView;
    QSplitter *splitter;
    QGroupBox *groupBox_3;
    QHBoxLayout *horizontalLayout_2;
    QTextEdit *srcPreview;
    QGroupBox *groupBox_4;
    QHBoxLayout *horizontalLayout;
    QTextEdit *dstPreview;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *EncodingConverterClass)
    {
        if (EncodingConverterClass->objectName().isEmpty())
            EncodingConverterClass->setObjectName(QString::fromUtf8("EncodingConverterClass"));
        EncodingConverterClass->resize(1025, 881);
        actOpenDir = new QAction(EncodingConverterClass);
        actOpenDir->setObjectName(QString::fromUtf8("actOpenDir"));
        centralWidget = new QWidget(EncodingConverterClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        groupBox_2 = new QGroupBox(centralWidget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setMaximumSize(QSize(16777215, 110));
        gridLayout = new QGridLayout(groupBox_2);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        btnSrcDir = new QPushButton(groupBox_2);
        btnSrcDir->setObjectName(QString::fromUtf8("btnSrcDir"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(btnSrcDir->sizePolicy().hasHeightForWidth());
        btnSrcDir->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnSrcDir, 0, 0, 1, 1);

        srcDirText = new QLineEdit(groupBox_2);
        srcDirText->setObjectName(QString::fromUtf8("srcDirText"));
        srcDirText->setReadOnly(true);

        gridLayout->addWidget(srcDirText, 0, 1, 1, 1);

        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 2, 1, 1);

        cboSrcEn = new QComboBox(groupBox_2);
        cboSrcEn->addItem(QString());
        cboSrcEn->addItem(QString());
        cboSrcEn->addItem(QString());
        cboSrcEn->setObjectName(QString::fromUtf8("cboSrcEn"));

        gridLayout->addWidget(cboSrcEn, 0, 3, 1, 1);

        btnDstDir = new QPushButton(groupBox_2);
        btnDstDir->setObjectName(QString::fromUtf8("btnDstDir"));
        sizePolicy.setHeightForWidth(btnDstDir->sizePolicy().hasHeightForWidth());
        btnDstDir->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnDstDir, 1, 0, 1, 1);

        dstDirText = new QLineEdit(groupBox_2);
        dstDirText->setObjectName(QString::fromUtf8("dstDirText"));
        dstDirText->setReadOnly(true);

        gridLayout->addWidget(dstDirText, 1, 1, 1, 1);

        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 2, 1, 1);

        cboDstEn = new QComboBox(groupBox_2);
        cboDstEn->addItem(QString());
        cboDstEn->addItem(QString());
        cboDstEn->addItem(QString());
        cboDstEn->setObjectName(QString::fromUtf8("cboDstEn"));

        gridLayout->addWidget(cboDstEn, 1, 3, 1, 1);

        btnStart = new QPushButton(groupBox_2);
        btnStart->setObjectName(QString::fromUtf8("btnStart"));

        gridLayout->addWidget(btnStart, 2, 3, 1, 1);


        verticalLayout->addWidget(groupBox_2);

        splitter_2 = new QSplitter(centralWidget);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setOrientation(Qt::Horizontal);
        treeView = new QTreeView(splitter_2);
        treeView->setObjectName(QString::fromUtf8("treeView"));
        treeView->setMaximumSize(QSize(300, 16777215));
        splitter_2->addWidget(treeView);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Vertical);
        groupBox_3 = new QGroupBox(splitter);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        horizontalLayout_2 = new QHBoxLayout(groupBox_3);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        srcPreview = new QTextEdit(groupBox_3);
        srcPreview->setObjectName(QString::fromUtf8("srcPreview"));
        srcPreview->setReadOnly(true);

        horizontalLayout_2->addWidget(srcPreview);

        splitter->addWidget(groupBox_3);
        groupBox_4 = new QGroupBox(splitter);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        horizontalLayout = new QHBoxLayout(groupBox_4);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        dstPreview = new QTextEdit(groupBox_4);
        dstPreview->setObjectName(QString::fromUtf8("dstPreview"));

        horizontalLayout->addWidget(dstPreview);

        splitter->addWidget(groupBox_4);
        splitter_2->addWidget(splitter);

        verticalLayout->addWidget(splitter_2);

        EncodingConverterClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(EncodingConverterClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1025, 23));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        EncodingConverterClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(EncodingConverterClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        EncodingConverterClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(EncodingConverterClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        EncodingConverterClass->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuFile->addAction(actOpenDir);

        retranslateUi(EncodingConverterClass);

        QMetaObject::connectSlotsByName(EncodingConverterClass);
    } // setupUi

    void retranslateUi(QMainWindow *EncodingConverterClass)
    {
        EncodingConverterClass->setWindowTitle(QCoreApplication::translate("EncodingConverterClass", "EncodingConverter", nullptr));
        actOpenDir->setText(QCoreApplication::translate("EncodingConverterClass", "Open", nullptr));
        groupBox_2->setTitle(QString());
        btnSrcDir->setText(QCoreApplication::translate("EncodingConverterClass", "\351\200\211\346\213\251\346\272\220\346\226\207\344\273\266\347\233\256\345\275\225", nullptr));
        label->setText(QCoreApplication::translate("EncodingConverterClass", "\351\200\211\346\213\251\346\272\220\346\226\207\344\273\266\347\274\226\347\240\201", nullptr));
        cboSrcEn->setItemText(0, QCoreApplication::translate("EncodingConverterClass", "GBK", nullptr));
        cboSrcEn->setItemText(1, QCoreApplication::translate("EncodingConverterClass", "UTF-8 with BOM", nullptr));
        cboSrcEn->setItemText(2, QCoreApplication::translate("EncodingConverterClass", "UTF-8 without BOM", nullptr));

        btnDstDir->setText(QCoreApplication::translate("EncodingConverterClass", "\351\200\211\346\213\251\344\277\235\345\255\230\347\233\256\345\275\225", nullptr));
        label_2->setText(QCoreApplication::translate("EncodingConverterClass", "\351\200\211\346\213\251\347\233\256\346\240\207\346\226\207\344\273\266\347\274\226\347\240\201", nullptr));
        cboDstEn->setItemText(0, QCoreApplication::translate("EncodingConverterClass", "GBK", nullptr));
        cboDstEn->setItemText(1, QCoreApplication::translate("EncodingConverterClass", "UTF-8 with BOM", nullptr));
        cboDstEn->setItemText(2, QCoreApplication::translate("EncodingConverterClass", "UTF-8 without BOM", nullptr));

        btnStart->setText(QCoreApplication::translate("EncodingConverterClass", "\345\274\200\345\247\213\350\275\254\346\215\242", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("EncodingConverterClass", "\346\272\220\346\226\207\344\273\266\351\242\204\350\247\210", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("EncodingConverterClass", "\347\233\256\346\240\207\346\226\207\344\273\266\351\242\204\350\247\210", nullptr));
        menuFile->setTitle(QCoreApplication::translate("EncodingConverterClass", "File", nullptr));
    } // retranslateUi

};

namespace Ui {
    class EncodingConverterClass: public Ui_EncodingConverterClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ENCODINGCONVERTER_H
