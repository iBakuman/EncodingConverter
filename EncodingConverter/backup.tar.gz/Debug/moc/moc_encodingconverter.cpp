/****************************************************************************
** Meta object code from reading C++ file 'encodingconverter.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../encodingconverter.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'encodingconverter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_EncodingConverter_t {
    QByteArrayData data[16];
    char stringdata0[267];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_EncodingConverter_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_EncodingConverter_t qt_meta_stringdata_EncodingConverter = {
    {
QT_MOC_LITERAL(0, 0, 17), // "EncodingConverter"
QT_MOC_LITERAL(1, 18, 23), // "on_actOpenDir_triggered"
QT_MOC_LITERAL(2, 42, 0), // ""
QT_MOC_LITERAL(3, 43, 20), // "on_btnSrcDir_clicked"
QT_MOC_LITERAL(4, 64, 20), // "on_btnDstDir_clicked"
QT_MOC_LITERAL(5, 85, 19), // "on_btnStart_clicked"
QT_MOC_LITERAL(6, 105, 31), // "on_cboDstEn_currentIndexChanged"
QT_MOC_LITERAL(7, 137, 5), // "index"
QT_MOC_LITERAL(8, 143, 31), // "on_cboSrcEn_currentIndexChanged"
QT_MOC_LITERAL(9, 175, 10), // "srcPreview"
QT_MOC_LITERAL(10, 186, 8), // "filepath"
QT_MOC_LITERAL(11, 195, 19), // "when_currentChanged"
QT_MOC_LITERAL(12, 215, 11), // "QModelIndex"
QT_MOC_LITERAL(13, 227, 7), // "current"
QT_MOC_LITERAL(14, 235, 8), // "previous"
QT_MOC_LITERAL(15, 244, 22) // "when_currentRowChanged"

    },
    "EncodingConverter\0on_actOpenDir_triggered\0"
    "\0on_btnSrcDir_clicked\0on_btnDstDir_clicked\0"
    "on_btnStart_clicked\0on_cboDstEn_currentIndexChanged\0"
    "index\0on_cboSrcEn_currentIndexChanged\0"
    "srcPreview\0filepath\0when_currentChanged\0"
    "QModelIndex\0current\0previous\0"
    "when_currentRowChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_EncodingConverter[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   59,    2, 0x08 /* Private */,
       3,    0,   60,    2, 0x08 /* Private */,
       4,    0,   61,    2, 0x08 /* Private */,
       5,    0,   62,    2, 0x08 /* Private */,
       6,    1,   63,    2, 0x08 /* Private */,
       8,    1,   66,    2, 0x08 /* Private */,
       9,    1,   69,    2, 0x08 /* Private */,
      11,    2,   72,    2, 0x08 /* Private */,
      15,    2,   77,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Bool, QMetaType::QString,   10,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 12,   13,   14,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 12,   13,   14,

       0        // eod
};

void EncodingConverter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<EncodingConverter *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_actOpenDir_triggered(); break;
        case 1: _t->on_btnSrcDir_clicked(); break;
        case 2: _t->on_btnDstDir_clicked(); break;
        case 3: _t->on_btnStart_clicked(); break;
        case 4: _t->on_cboDstEn_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->on_cboSrcEn_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: { bool _r = _t->srcPreview((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 7: _t->when_currentChanged((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< const QModelIndex(*)>(_a[2]))); break;
        case 8: _t->when_currentRowChanged((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< const QModelIndex(*)>(_a[2]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject EncodingConverter::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_EncodingConverter.data,
    qt_meta_data_EncodingConverter,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *EncodingConverter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *EncodingConverter::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_EncodingConverter.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int EncodingConverter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
